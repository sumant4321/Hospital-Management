<?php
           include 'config.php';
                $id=$_POST['data'];
                $dept = $_POST['dept'];
                echo 'ankit';
                 $hosp1 = "SELECT * FROM hosp_dept WHERE choose_hosp_id=$id AND dept='$dept'";
                 $result1 = mysqli_query($conn,$hosp1);
                 if (mysqli_num_rows($result1) == 0) {
               
                    $sql = "INSERT INTO hosp_dept (choose_hosp_id, dept , enable,selectedDates)
                    VALUES ($id , '$dept', 'yes','')";
                    if (mysqli_query($conn, $sql)) {
                      echo "New record created successfully";
                    } else {
                      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                    }

                 }                
                        
                 else{
                     echo "<div class='alert alert-danger' role='alert'>
                     This is Allready choosen.
                   </div>";               
                 }
            
?>
 