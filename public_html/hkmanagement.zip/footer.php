<div class="footer" style="background-color: #276b94;background-image: url('./image/footer.png');">
        <div class="container">
        <div class="row">          
          <div class="col-6 col-md-6 col-lg-6 col-sm-6 copyright">            
              <p class=" mb-3" style="color: white;font-family:  'Caladea', serif;padding: 100px 0 0 0;">© COPYRIGHT 2020, NIC. ALL RIGHTS RESERVED ®.</p>
            </div>
            <div class="col-6 col-md-6 col-lg-6 col-sm-6 contact-us">            
              <p class="mt-3 mb-3" style="font-family:'Caladea', serif;font-size:22px">contact us</p>
              <div class="contact-content">
              <i class="fas fa-map-marker-alt  fa-1x"></i>
              <span class="ml-2" style="font-family:Cochin;">ankit yadav Pvt.Ltd.</span><br>
              <span style="font-family:Cochin;">mairwa,siwan,bihar 841239</span><br>
              <i class="fas fa-phone-alt fa-1x"></i>
              <span class="ml-2" style="font-family:Cochin;">+91-7001739196</span><br>
              <i class="far fa-envelope"></i>
              <span class="ml-2 " style="font-family:Cochin;"><a href="mailto:"  style="color:white">ankityadav66666@gmail.com</a></span><br>              
              <i class="fas fa-mobile-alt"></i>
              <span class="ml-2" style="font-family:Cochin;">+91-7001739196</span><br>
              <div class="contact-icon mt-3">
              <i class="fab fa-facebook" ></i>
              <i class="fab fa-google-plus"></i>
              <i class="fab fa-linkedin"></i>
            </div>
          </div>
          </div>
        </div>
        </div>