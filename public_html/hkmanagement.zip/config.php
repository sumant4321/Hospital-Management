<?php
error_reporting(E_ALL & ~ E_NOTICE);

$servername = "localhost";
$username = "id12891733_hkm";
$password = "Ankityadav@06";
$db = "id12891733_madbag";

$conn = mysqli_connect($servername, $username, $password, $db);

?>